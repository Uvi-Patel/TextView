//
//  ViewController.swift
//  Textview_demo
//
//  Created by MAC on 01/06/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextViewDelegate {
    
    let screenWidth = UIScreen.main.bounds.size.width
    let screeHight = UIScreen.main.bounds.size.height
    
    var topSafeArea: CGFloat{
        if #available(iOS 11.0, *) {
            return UIApplication.shared.windows[0].safeAreaInsets.top
        }
        return 0
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let mytextview = UITextView()
        //mytextview.frame = CGRect(x: (screenWidth-300)/2, y: (screeHight-100)/2, width: 300, height: 100)
        mytextview.frame = CGRect(x: 50, y: 100, width: (screenWidth-65), height: (screeHight-120))
       // mytextview.frame = CGRect(x: 10, y: 10, width: self.view.frame.size.width-20, height: self.view.frame.size.height-20)
      //  mytextview.contentInsetAdjustmentBehavior = .automatic
        mytextview.text = "Type Your Comments"
        mytextview.textColor = UIColor.white
        mytextview.font = UIFont(name: "verdana", size: 18.0)
        mytextview.returnKeyType = .done
        mytextview.delegate = self
       // mytextview.font = UIFont.italicSystemFont(ofSize: 20)
       // mytextview.textColor = UIColor.green
        mytextview.backgroundColor = UIColor.lightGray
        mytextview.autocapitalizationType = UITextAutocapitalizationType.allCharacters
        mytextview.isSelectable = true
        mytextview.isEditable = true
        mytextview.layer.cornerRadius = 10
        mytextview.autocorrectionType = UITextAutocorrectionType.yes
       // mytextview.spellCheckingType = UITextSpellCheckingType.yes
       // mytextview.dataDetectorTypes = UIDataDetectorTypes.link
       // mytextview.backgroundColor = UIColor(red: 39/255, green: 53/255, blue: 182/255, alpha: 1)
//        mytextview.text = "Placeholder"
//        mytextview.textColor = UIColor.systemPink
//        mytextview.becomeFirstResponder()
//        mytextview.selectedTextRange = mytextview.textRange(from: mytextview.beginningOfDocument, to: mytextview.beginningOfDocument)
        self.view.addSubview(mytextview)
        
        // Do any additional setup after loading the view.
    }
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()


    func textViewDidBeginEditing(_ mytextview: UITextView) {
        if mytextview.text == "Type Your Comments"
        {
            mytextview.text = ""
            mytextview.textColor = UIColor.black
            mytextview.font = UIFont(name: "verdana", size: 13.0)
        }
    }

    func textView(_ mytextview: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if text == "\n"
        {
            mytextview.resignFirstResponder()
        }
        return true
    }

}

}
